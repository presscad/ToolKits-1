/* Copyright 2018 the SumatraPDF project authors (see AUTHORS file).
   License: Simplified BSD (see COPYING.BSD) */

namespace fitz {

Gdiplus::Bitmap* ImageFromData(const char* data, size_t len);
}
