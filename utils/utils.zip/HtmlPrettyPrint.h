/* Copyright 2018 the SumatraPDF project authors (see AUTHORS file).
   License: Simplified BSD (see COPYING.BSD) */

char* PrettyPrintHtml(const char* s, size_t len, size_t& lenOut);
